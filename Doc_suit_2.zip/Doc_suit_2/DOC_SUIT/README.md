Document Suite API
A FastAPI-based RESTful API for managing users, projects, documents, and their components (pages, sections, tables, images, processing logs) using MongoDB. This application supports CRUD operations for a document management system, designed for scalability and maintainability.
Table of Contents

Features
Prerequisites
Installation
Running the Application
API Documentation
Testing
Project Structure
Contributing
License

Features

CRUD Operations: Create, read, update, and delete users, projects, documents, pages, sections, tables, images, and processing logs.
MongoDB Integration: Uses PyMongo for efficient database operations.
Pydantic Validation: Ensures data integrity with schema validation.
API Key Authentication: Secures endpoints with API key validation.
Logging: Configurable logging to console and file.
Docker Support: Containerized setup with Docker and Docker Compose.
Testing: Basic unit tests using pytest.

Prerequisites

Python 3.11+
MongoDB 6.0+ (running locally or via Docker)
Docker and Docker Compose (optional, for containerized setup)
Git

Installation

Clone the Repository:
git clone https://github.com/your-repo/my_fastapi_mongodb_project.git
cd my_fastapi_mongodb_project


Create a Virtual Environment:
python -m venv venv
.\venv\Scripts\Activate.ps1


Install Dependencies:
pip install -r requirements.txt


Configure Environment Variables:

Copy the example .env file:Copy-Item .env.example .env


Edit .env to set your API_KEY and other configurations:PROJECT_NAME=Document Suite API
API_KEY=your_secure_api_key_here
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=document_suite
ENVIRONMENT=development
LOG_LEVEL=INFO




Start MongoDB (if not using Docker):

Ensure MongoDB is running locally:mongod


Or start it as a service:Start-Service -Name "MongoDB"





Running the Application
Without Docker

Activate the virtual environment:.\venv\Scripts\Activate.ps1


Run the FastAPI server:uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload


Access the API at http://localhost:8000 and the interactive Swagger UI at http://localhost:8000/docs.

With Docker

Build and start the containers:docker-compose up --build


Access the API at http://localhost:8000 and Swagger UI at http://localhost:8000/docs.
Stop the containers:docker-compose down



API Documentation

Interactive Swagger UI: http://localhost:8000/docs
OpenAPI JSON: http://localhost:8000/openapi.json
Frontend developers can refer to API_DOCUMENTATION_FOR_FRONTEND.md for detailed endpoint information, request/response formats, and error handling.

Testing
Run tests using pytest:
pytest tests/ -v

Tests cover basic endpoint functionality for the root, users, and projects.
Project Structure
my_fastapi_mongodb_project/
├── app/
│   ├── main.py               # FastAPI application entry point
│   ├── api/
│   │   ├── v1/
│   │   │   ├── routes/       # API routes for each collection
│   │   │   ├── dependencies.py
│   ├── core/
│   │   ├── config.py         # Environment configuration
│   │   ├── database.py       # MongoDB connection
│   │   ├── logging.py        # Logging setup
│   ├── models/               # Pydantic models for MongoDB documents
│   ├── schemas/              # Pydantic schemas for API validation
│   ├── services/             # Business logic for CRUD operations
│   ├── utils/                # Utilities (auth, exceptions, validators)
├── tests/                    # Unit tests
├── .env                      # Environment variables
├── .gitignore
├── requirements.txt          # Python dependencies
├── Dockerfile                # Docker configuration for FastAPI
├── docker-compose.yml        # Docker Compose for app and MongoDB
├── README.md
├── API_DOCUMENTATION_FOR_FRONTEND.md

Contributing

Fork the repository.
Create a feature branch (git checkout -b feature/your-feature).
Commit changes (git commit -m "Add your feature").
Push to the branch (git push origin feature/your-feature).
Open a pull request.

License
MIT License. See LICENSE for details.
