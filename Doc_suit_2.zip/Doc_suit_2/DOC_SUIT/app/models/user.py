from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class UserModel(BaseModel):
    id: Optional[str] = None
    username: str
    email: str
    full_name: str
    user_mod: str
    created_at: datetime
    updated_at: datetime
    last_login: Optional[datetime]
    is_active: bool

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }