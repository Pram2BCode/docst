from datetime import datetime
from typing import Dict, Optional
from pydantic import BaseModel

class DocumentModel(BaseModel):
    id: str
    project_id: str
    document_name: str
    original_filename: str
    file_path: str
    file_size: int
    file_type: str
    mime_type: str
    total_pages: int
    access_mod_doc: str
    checksum: str
    version: int
    extraction_status: str
    extraction_metadata: Dict
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
        allow_population_by_field_name = True
        arbitrary_types_allowed = True