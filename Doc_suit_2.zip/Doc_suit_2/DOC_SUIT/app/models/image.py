from pydantic import BaseModel
from typing import Optional, Dict
from datetime import datetime

class ImageModel(BaseModel):
    id: Optional[str] = None
    doc_id: str
    page_id: str
    section_id: Optional[str]
    image_path: str
    thumbnail_path: str
    page_number: int
    image_type: str
    image_format: str
    dimensions: Dict
    alt_text: str
    caption: str
    extraction_method: str
    file_size: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }