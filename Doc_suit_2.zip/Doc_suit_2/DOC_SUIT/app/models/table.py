from pydantic import BaseModel
from typing import Optional, Dict, List
from datetime import datetime

class TableModel(BaseModel):
    id: Optional[str] = None
    section_id: str
    doc_id: str
    page_number: int
    table_structure: Dict
    table_data: List[List[str]]
    table_caption: str
    extraction_method: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }