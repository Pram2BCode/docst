from pydantic import BaseModel
from typing import Optional, Dict
from datetime import datetime

class PageModel(BaseModel):
    id: Optional[str] = None
    doc_id: str
    page_number: int
    page_content: Dict
    page_dimensions: Dict
    rotation: int
    extraction_confidence: float
    page_thumbnail: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }