from pydantic import BaseModel
from typing import Optional, List, Dict
from datetime import datetime

class ProjectModel(BaseModel):
    id: Optional[str] = None
    project_name: str
    project_description: str
    owner_id: str
    project_access: str
    shared_users: List[str]
    created_at: datetime
    updated_at: datetime
    is_archived: bool
    tags: List[str]
    metadata: Dict

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }