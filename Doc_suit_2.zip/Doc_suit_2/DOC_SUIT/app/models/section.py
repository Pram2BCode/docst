from pydantic import BaseModel
from typing import Optional, Dict, List
from datetime import datetime

class SectionModel(BaseModel):
    id: Optional[str] = None
    doc_id: str
    page_id: str
    page_number: int
    sequence_number: int
    section_type: str
    section_level: int
    section_heading: str
    section_body: str
    formatted_content: Dict
    font_info: Dict
    text_formatting: Dict
    parent_section_id: Optional[str]
    child_sections: List[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }