from pydantic import BaseModel
from typing import Optional, Dict
from datetime import datetime

class ProcessingLogModel(BaseModel):
    id: Optional[str] = None
    doc_id: str
    processing_stage: str
    status: str
    error_message: str
    processing_time: int
    timestamp: datetime
    metadata: Dict
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }