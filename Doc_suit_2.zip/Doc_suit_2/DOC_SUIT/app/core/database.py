from pymongo import MongoClient
from app.core.config import settings
from app.services.schema_service import create_all_indexes

client = None
db = None

def init_db():
    global client, db
    try:
        client = MongoClient(settings.MONGODB_URL)
        db = client[settings.DATABASE_NAME]
        create_all_indexes(db)
        print("MongoDB connection established and indexes created")
    except Exception as e:
        print(f"Failed to connect to MongoDB: {e}")
        raise

def get_db():
    if db is None:
        init_db()
    return db

def close_db():
    global client
    if client:
        client.close()
        print("MongoDB connection closed")