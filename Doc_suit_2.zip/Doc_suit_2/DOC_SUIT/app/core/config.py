from pydantic import BaseSettings

class Settings(BaseSettings):
    API_KEY: str
    MONGODB_URL: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "document_suite"
    UPLOAD_DIR: str = "C:/uploads/documents"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()