from uuid import UUID

def validate_uuid(value: str) -> str:
    try:
        UUID(value, version=4)
        return value
    except ValueError:
        raise ValueError("Invalid UUID")