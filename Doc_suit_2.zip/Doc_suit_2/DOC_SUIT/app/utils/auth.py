from fastapi import HTTPException, status
from app.core.config import settings

def verify_api_key(api_key: str):
    if api_key != settings.API_KEY:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key")
    return api_key