from pydantic import BaseModel, validator
from typing import Optional, Dict, List
from datetime import datetime
from app.utils.validators import validate_uuid

class TableCreate(BaseModel):
    section_id: str
    doc_id: str
    page_number: int
    table_structure: Dict
    table_data: List[List[str]]
    table_caption: str = ""
    extraction_method: str = "auto"

    @validator("section_id")
    def validate_section_id(cls, v):
        return validate_uuid(v)

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("extraction_method")
    def validate_extraction_method(cls, v):
        valid_methods = ["auto", "manual"]
        if v not in valid_methods:
            raise ValueError(f"extraction_method must be one of {valid_methods}")
        return v

    @validator("page_number")
    def validate_page_number(cls, v):
        if v < 1:
            raise ValueError("page_number must be positive")
        return v

class TableResponse(BaseModel):
    id: str
    section_id: str
    doc_id: str
    page_number: int
    table_structure: Dict
    table_data: List[List[str]]
    table_caption: str
    extraction_method: str
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("section_id")
    def validate_section_id(cls, v):
        return validate_uuid(v)

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    class Config:
        orm_mode = True