from pydantic import BaseModel, validator
from typing import Optional, Dict
from datetime import datetime
from app.utils.validators import validate_uuid

class ImageCreate(BaseModel):
    doc_id: str
    page_id: str
    section_id: Optional[str] = None
    image_path: str
    thumbnail_path: str = ""
    page_number: int
    image_type: str
    image_format: str
    dimensions: Dict
    alt_text: str = ""
    caption: str = ""
    extraction_method: str = "auto"
    file_size: int = 0

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("page_id")
    def validate_page_id(cls, v):
        return validate_uuid(v)

    @validator("section_id")
    def validate_section_id(cls, v):
        if v:
            return validate_uuid(v)
        return v

    @validator("image_type")
    def validate_image_type(cls, v):
        valid_types = ["figure", "logo", "icon", "other"]
        if v not in valid_types:
            raise ValueError(f"image_type must be one of {valid_types}")
        return v

    @validator("image_format")
    def validate_image_format(cls, v):
        valid_formats = ["jpg", "png", "gif", "bmp", "tiff"]
        if v not in valid_formats:
            raise ValueError(f"image_format must be one of {valid_formats}")
        return v

    @validator("page_number")
    def validate_page_number(cls, v):
        if v < 1:
            raise ValueError("page_number must be positive")
        return v

class ImageResponse(BaseModel):
    id: str
    doc_id: str
    page_id: str
    section_id: Optional[str]
    image_path: str
    thumbnail_path: str
    page_number: int
    image_type: str
    image_format: str
    dimensions: Dict
    alt_text: str
    caption: str
    extraction_method: str
    file_size: int
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("page_id")
    def validate_page_id(cls, v):
        return validate_uuid(v)

    @validator("section_id")
    def validate_section_id(cls, v):
        if v:
            return validate_uuid(v)
        return v

    class Config:
        orm_mode = True