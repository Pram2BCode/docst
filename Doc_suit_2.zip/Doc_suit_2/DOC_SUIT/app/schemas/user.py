from pydantic import BaseModel, EmailStr, validator
from typing import Optional
from datetime import datetime
from app.utils.validators import validate_uuid

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    full_name: str
    user_mod: str = "private"

    @validator("user_mod")
    def validate_user_mod(cls, v):
        if v not in ["public", "private"]:
            raise ValueError("user_mod must be 'public' or 'private'")
        return v

class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: str
    user_mod: str
    created_at: datetime
    updated_at: datetime
    last_login: Optional[datetime]
    is_active: bool

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    class Config:
        orm_mode = True