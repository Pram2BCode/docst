from pydantic import BaseModel, validator
from typing import Optional, Dict
from datetime import datetime
from app.utils.validators import validate_uuid

class PageCreate(BaseModel):
    doc_id: str
    page_number: int
    page_content: Dict
    page_dimensions: Dict
    rotation: int = 0
    extraction_confidence: float = 1.0
    page_thumbnail: str = ""

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("page_number")
    def validate_page_number(cls, v):
        if v < 1:
            raise ValueError("page_number must be positive")
        return v

    @validator("extraction_confidence")
    def validate_extraction_confidence(cls, v):
        if not 0.0 <= v <= 1.0:
            raise ValueError("extraction_confidence must be between 0.0 and 1.0")
        return v

class PageResponse(BaseModel):
    id: str
    doc_id: str
    page_number: int
    page_content: Dict
    page_dimensions: Dict
    rotation: int
    extraction_confidence: float
    page_thumbnail: str
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    class Config:
        orm_mode = True