from pydantic import BaseModel, validator
from typing import Optional, Dict, List
from datetime import datetime
from app.utils.validators import validate_uuid

class SectionCreate(BaseModel):
    doc_id: str
    page_id: str
    page_number: int
    sequence_number: int
    section_type: str
    section_level: int = 1
    section_heading: str = ""
    section_body: str = ""
    formatted_content: Dict = {}
    font_info: Dict = {}
    text_formatting: Dict = {}
    parent_section_id: Optional[str] = None
    child_sections: List[str] = []

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("page_id")
    def validate_page_id(cls, v):
        return validate_uuid(v)

    @validator("parent_section_id")
    def validate_parent_section_id(cls, v):
        if v:
            return validate_uuid(v)
        return v

    @validator("child_sections")
    def validate_child_sections(cls, v):
        return [validate_uuid(sid) for sid in v]

    @validator("section_type")
    def validate_section_type(cls, v):
        valid_types = ["heading", "paragraph", "list", "table", "image"]
        if v not in valid_types:
            raise ValueError(f"section_type must be one of {valid_types}")
        return v

    @validator("sequence_number")
    def validate_sequence_number(cls, v):
        if v < 1:
            raise ValueError("sequence_number must be positive")
        return v

class SectionResponse(BaseModel):
    id: str
    doc_id: str
    page_id: str
    page_number: int
    sequence_number: int
    section_type: str
    section_level: int
    section_heading: str
    section_body: str
    formatted_content: Dict
    font_info: Dict
    text_formatting: Dict
    parent_section_id: Optional[str]
    child_sections: List[str]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("page_id")
    def validate_page_id(cls, v):
        return validate_uuid(v)

    @validator("parent_section_id")
    def validate_parent_section_id(cls, v):
        if v:
            return validate_uuid(v)
        return v

    @validator("child_sections")
    def validate_child_sections(cls, v):
        return [validate_uuid(sid) for sid in v]

    class Config:
        orm_mode = True