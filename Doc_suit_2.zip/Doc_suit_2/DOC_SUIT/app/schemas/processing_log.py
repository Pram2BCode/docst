from pydantic import BaseModel, validator
from typing import Optional, Dict
from datetime import datetime
from app.utils.validators import validate_uuid

class ProcessingLogCreate(BaseModel):
    doc_id: str
    processing_stage: str
    status: str
    error_message: str = ""
    processing_time: int
    metadata: Dict = {}

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    @validator("status")
    def validate_status(cls, v):
        valid_statuses = ["pending", "processing", "completed", "failed"]
        if v not in valid_statuses:
            raise ValueError(f"status must be one of {valid_statuses}")
        return v

    @validator("processing_time")
    def validate_processing_time(cls, v):
        if v < 0:
            raise ValueError("processing_time must be non-negative")
        return v

class ProcessingLogResponse(BaseModel):
    id: str
    doc_id: str
    processing_stage: str
    status: str
    error_message: str
    processing_time: int
    timestamp: datetime
    metadata: Dict
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("doc_id")
    def validate_doc_id(cls, v):
        return validate_uuid(v)

    class Config:
        orm_mode = True