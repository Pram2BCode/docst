from pydantic import BaseModel, validator
from typing import Optional, List, Dict
from datetime import datetime
from app.utils.validators import validate_uuid

class ProjectCreate(BaseModel):
    project_name: str
    project_description: Optional[str] = ""
    owner_id: str
    project_access: str = "private"
    shared_users: List[str] = []
    tags: List[str] = []
    metadata: Dict = {}

    @validator("project_access")
    def validate_project_access(cls, v):
        if v not in ["public", "private"]:
            raise ValueError("project_access must be 'public' or 'private'")
        return v

    @validator("owner_id")
    def validate_owner_id(cls, v):
        return validate_uuid(v)

    @validator("shared_users")
    def validate_shared_users(cls, v):
        return [validate_uuid(uid) for uid in v]

class ProjectResponse(BaseModel):
    id: str
    project_name: str
    project_description: str
    owner_id: str
    project_access: str
    shared_users: List[str]
    created_at: datetime
    updated_at: datetime
    is_archived: bool
    tags: List[str]
    metadata: Dict

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("owner_id")
    def validate_owner_id(cls, v):
        return validate_uuid(v)

    @validator("shared_users")
    def validate_shared_users(cls, v):
        return [validate_uuid(uid) for uid in v]

    class Config:
        orm_mode = True