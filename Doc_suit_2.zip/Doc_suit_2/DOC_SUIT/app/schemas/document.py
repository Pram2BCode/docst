from pydantic import BaseModel, validator
from typing import Optional, Dict
from datetime import datetime
from app.utils.validators import validate_uuid

class DocumentCreate(BaseModel):
    project_id: str
    document_name: str
    original_filename: str
    file_path: str
    file_size: int
    file_type: str
    mime_type: str
    total_pages: int
    access_mod_doc: str = "private"
    checksum: str
    version: int = 1

    @validator("project_id")
    def validate_project_id(cls, v):
        return validate_uuid(v)

    @validator("access_mod_doc")
    def validate_access_mod_doc(cls, v):
        if v not in ["public", "private"]:
            raise ValueError("access_mod_doc must be 'public' or 'private'")
        return v

    @validator("file_type")
    def validate_file_type(cls, v):
        valid_types = ["pdf", "doc", "docx", "txt", "jpg", "png"]
        if v not in valid_types:
            raise ValueError(f"file_type must be one of {valid_types}")
        return v

class DocumentResponse(BaseModel):
    id: str
    project_id: str
    document_name: str
    original_filename: str
    file_path: str
    file_size: int
    file_type: str
    mime_type: str
    total_pages: int
    access_mod_doc: str
    extraction_status: str
    extraction_metadata: Dict
    created_at: datetime
    updated_at: datetime
    checksum: str
    version: int

    @validator("id")
    def validate_id(cls, v):
        return validate_uuid(v)

    @validator("project_id")
    def validate_project_id(cls, v):
        return validate_uuid(v)

    class Config:
        orm_mode = True