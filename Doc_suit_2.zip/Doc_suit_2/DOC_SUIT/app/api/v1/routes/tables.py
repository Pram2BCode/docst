from fastapi import APIRouter, Depends, HTTPException, status
from app.schemas.tables import tablesCreate, tablesResponse
from app.services.tables_service import tablesService
from app.utils.auth import verify_api_key

router = APIRouter()

@router.post("/", response_model=tablesResponse, status_code=status.HTTP_201_CREATED)
async def create_tables(tables: tablesCreate, api_key: str = Depends(verify_api_key)):
    try:
        tables_service = tablesService()
        result = tables_service.create_tables(tables.dict())
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=result["error"])
        return result["tables"]
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/{id}", response_model=tablesResponse)
async def get_tables(id: str, api_key: str = Depends(verify_api_key)):
    try:
        tables_service = tablesService()
        result = tables_service.get_tables_by_id(id)
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=result["error"])
        return result["tables"]
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))