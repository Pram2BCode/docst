from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from typing import List
from app.schemas.document import DocumentCreate, DocumentResponse
from app.services.document_service import DocumentService
from app.utils.auth import verify_api_key
from app.utils.validators import validate_uuid
import os
from app.core.config import settings

router = APIRouter()

@router.post("/", response_model=List[DocumentResponse], status_code=status.HTTP_201_CREATED)
async def create_documents(
    project_id: str = Form(...),
    files: List[UploadFile] = File(...),
    access_mod_doc: str = Form("private"),
    api_key: str = Depends(verify_api_key)
):
    try:
        # Validate that no more than 5 files are uploaded
        if len(files) > 5:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot upload more than 5 files at once"
            )

        # Validate project_id as UUID
        validate_uuid(project_id)

        # Validate access_mod_doc
        if access_mod_doc not in ["public", "private"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="access_mod_doc must be 'public' or 'private'"
            )

        # Initialize document service
        document_service = DocumentService()
        created_documents = []

        # Process each file
        for file in files:
            # Validate file type
            file_type = file.filename.split(".")[-1].lower()
            valid_types = ["pdf", "doc", "docx", "txt", "jpg", "png"]
            if file_type not in valid_types:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid file type: {file_type}. Supported types: {valid_types}"
                )

            # Generate file path
            file_path = os.path.join(settings.UPLOAD_DIR, file.filename)
            # Ensure unique filename to avoid overwrites
            base, ext = os.path.splitext(file_path)
            counter = 1
            while os.path.exists(file_path):
                file_path = f"{base}_{counter}{ext}"
                counter += 1

            # Save file to disk
            with open(file_path, "wb") as f:
                f.write(await file.read())

            # Calculate file size
            file_size = os.path.getsize(file_path)

            # Create document data
            document_data = {
                "project_id": project_id,
                "document_name": file.filename,
                "original_filename": file.filename,
                "file_path": file_path,
                "file_size": file_size,
                "file_type": file_type,
                "mime_type": file.content_type,
                "total_pages": 1,  # Placeholder; update later if needed
                "access_mod_doc": access_mod_doc,
                "checksum": "placeholder_checksum",  # Implement checksum calculation if needed
                "version": 1
            }

            # Create document in database
            result = document_service.create_document(document_data)
            if not result["success"]:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=result["error"]
                )
            created_documents.append(result["document"])

        return created_documents
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid UUID"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/{id}", response_model=DocumentResponse)
async def get_document(id: str, api_key: str = Depends(verify_api_key)):
    try:
        validate_uuid(id)
        document_service = DocumentService()
        result = document_service.get_document_by_id(id)
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=result["error"])
        return result["document"]
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid UUID")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.delete("/{id}", status_code=status.HTTP_200_OK)
async def delete_document(id: str, api_key: str = Depends(verify_api_key)):
    try:
        validate_uuid(id)
        document_service = DocumentService()
        result = document_service.delete_document(id)
        if not result["success"]:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=result["error"])
        return {"message": f"Deleted {result['deleted_count']} document(s)"}
    except ValueError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid UUID")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))