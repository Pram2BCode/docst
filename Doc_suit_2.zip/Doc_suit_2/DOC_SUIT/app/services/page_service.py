from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class PageService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.pages

    def create_page(self, page_data: dict):
        try:
            page = {
                "_id": str(uuid4()),
                "doc_id": page_data["doc_id"],
                "page_number": page_data["page_number"],
                "page_content": page_data.get("page_content", {}),
                "page_dimensions": page_data.get("page_dimensions", {}),
                "rotation": page_data.get("rotation", 0),
                "extraction_confidence": page_data.get("extraction_confidence", 1.0),
                "page_thumbnail": page_data.get("page_thumbnail", ""),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            result = self.collection.insert_one(page)
            page["id"] = page["_id"]
            del page["_id"]
            return {"success": True, "page": page}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_page_by_id(self, page_id: str):
        try:
            page = self.collection.find_one({"_id": page_id})
            if not page:
                return {"success": False, "error": "Page not found"}
            page["id"] = page["_id"]
            del page["_id"]
            return {"success": True, "page": page}
        except Exception as e:
            return {"success": False, "error": str(e)}