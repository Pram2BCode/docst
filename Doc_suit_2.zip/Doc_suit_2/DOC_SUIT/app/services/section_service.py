from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class SectionService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.sections

    def create_section(self, section_data: dict):
        try:
            section = {
                "_id": str(uuid4()),
                "doc_id": section_data["doc_id"],
                "page_id": section_data["page_id"],
                "page_number": section_data["page_number"],
                "sequence_number": section_data["sequence_number"],
                "section_type": section_data["section_type"],
                "section_level": section_data.get("section_level", 1),
                "section_heading": section_data.get("section_heading", ""),
                "section_body": section_data.get("section_body", ""),
                "formatted_content": section_data.get("formatted_content", {}),
                "font_info": section_data.get("font_info", {}),
                "text_formatting": section_data.get("text_formatting", {}),
                "parent_section_id": section_data.get("parent_section_id"),
                "child_sections": section_data.get("child_sections", []),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            result = self.collection.insert_one(section)
            section["id"] = section["_id"]
            del section["_id"]
            return {"success": True, "section": section}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_section_by_id(self, section_id: str):
        try:
            section = self.collection.find_one({"_id": section_id})
            if not section:
                return {"success": False, "error": "Section not found"}
            section["id"] = section["_id"]
            del section["_id"]
            return {"success": True, "section": section}
        except Exception as e:
            return {"success": False, "error": str(e)}