from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class TableService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.tables

    def create_table(self, table_data: dict):
        try:
            table = {
                "_id": str(uuid4()),
                "section_id": table_data["section_id"],
                "doc_id": table_data["doc_id"],
                "page_number": table_data["page_number"],
                "table_structure": table_data.get("table_structure", {}),
                "table_data": table_data.get("table_data", []),
                "table_caption": table_data.get("table_caption", ""),
                "extraction_method": table_data.get("extraction_method", "auto"),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            result = self.collection.insert_one(table)
            table["id"] = table["_id"]
            del table["_id"]
            return {"success": True, "table": table}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_table_by_id(self, table_id: str):
        try:
            table = self.collection.find_one({"_id": table_id})
            if not table:
                return {"success": False, "error": "Table not found"}
            table["id"] = table["_id"]
            del table["_id"]
            return {"success": True, "table": table}
        except Exception as e:
            return {"success": False, "error": str(e)}