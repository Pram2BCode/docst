def create_all_indexes(db):
    try:
        db.users.create_index("username", unique=True)
        db.users.create_index("email", unique=True)
        db.projects.create_index("owner_id")
        db.projects.create_index("shared_users")
        db.documents.create_index("project_id")
        db.documents.create_index([("document_name", "text")])
        db.pages.create_index([("doc_id", 1), ("page_number", 1)])
        db.sections.create_index([("doc_id", 1), ("page_number", 1), ("sequence_number", 1)])
        db.sections.create_index([("section_heading", "text"), ("section_body", "text")])
        db.tables.create_index([("doc_id", 1), ("page_number", 1)])
        db.images.create_index([("doc_id", 1), ("page_number", 1)])
        db.document_processing_log.create_index("doc_id")
        print("Indexes created successfully")
        return {"success": True}
    except Exception as e:
        print(f"Error creating indexes: {e}")
        return {"success": False, "error": str(e)}