from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class ImageService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.images

    def create_image(self, image_data: dict):
        try:
            image = {
                "_id": str(uuid4()),
                "doc_id": image_data["doc_id"],
                "page_id": image_data["page_id"],
                "section_id": image_data.get("section_id"),
                "image_path": image_data["image_path"],
                "thumbnail_path": image_data.get("thumbnail_path", ""),
                "page_number": image_data["page_number"],
                "image_type": image_data["image_type"],
                "image_format": image_data["image_format"],
                "dimensions": image_data.get("dimensions", {}),
                "alt_text": image_data.get("alt_text", ""),
                "caption": image_data.get("caption", ""),
                "extraction_method": image_data.get("extraction_method", "auto"),
                "file_size": image_data.get("file_size", 0),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            result = self.collection.insert_one(image)
            image["id"] = image["_id"]
            del image["_id"]
            return {"success": True, "image": image}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_image_by_id(self, image_id: str):
        try:
            image = self.collection.find_one({"_id": image_id})
            if not image:
                return {"success": False, "error": "Image not found"}
            image["id"] = image["_id"]
            del image["id"]
            return {"success": True, "image": image}
        except Exception as e:
            return {"success": False, "error": str(e)}