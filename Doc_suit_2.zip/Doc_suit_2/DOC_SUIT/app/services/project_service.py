from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class ProjectService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.projects

    def create_project(self, project_data: dict):
        try:
            project = {
                "_id": str(uuid4()),
                "project_name": project_data["project_name"],
                "project_description": project_data.get("project_description", ""),
                "owner_id": project_data["owner_id"],
                "project_access": project_data.get("project_access", "private"),
                "shared_users": project_data.get("shared_users", []),
                "tags": project_data.get("tags", []),
                "metadata": project_data.get("metadata", {}),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "is_archived": False
            }
            result = self.collection.insert_one(project)
            project["id"] = project["_id"]
            del project["_id"]
            return {"success": True, "project": project}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_project_by_id(self, project_id: str):
        try:
            project = self.collection.find_one({"_id": project_id})
            if not project:
                return {"success": False, "error": "Project not found"}
            project["id"] = project["_id"]
            del project["_id"]
            return {"success": True, "project": project}
        except Exception as e:
            return {"success": False, "error": str(e)}