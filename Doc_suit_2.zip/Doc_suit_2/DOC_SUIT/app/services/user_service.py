from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class UserService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.users

    def create_user(self, user_data: dict):
        try:
            user = {
                "_id": str(uuid4()),
                "username": user_data["username"],
                "email": user_data["email"],
                "full_name": user_data["full_name"],
                "user_mod": user_data.get("user_mod", "private"),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "last_login": None,
                "is_active": True
            }
            result = self.collection.insert_one(user)
            user["id"] = user["_id"]
            del user["_id"]
            return {"success": True, "user": user}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_user_by_id(self, user_id: str):
        try:
            user = self.collection.find_one({"_id": user_id})
            if not user:
                return {"success": False, "error": "User not found"}
            user["id"] = user["_id"]
            del user["_id"]
            return {"success": True, "user": user}
        except Exception as e:
            return {"success": False, "error": str(e)}