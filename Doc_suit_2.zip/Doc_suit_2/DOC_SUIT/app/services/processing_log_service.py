from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class ProcessingLogService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.document_processing_log

    def create_processing_log(self, log_data: dict):
        try:
            log = {
                "_id": str(uuid4()),
                "doc_id": log_data["doc_id"],
                "processing_stage": log_data["processing_stage"],
                "status": log_data["status"],
                "error_message": log_data.get("error_message", ""),
                "processing_time": log_data["processing_time"],
                "timestamp": datetime.utcnow(),
                "metadata": log_data.get("metadata", {}),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            result = self.collection.insert_one(log)
            log["id"] = log["_id"]
            del log["_id"]
            return {"success": True, "processing_log": log}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_processing_log_by_id(self, log_id: str):
        try:
            log = self.collection.find_one({"_id": log_id})
            if not log:
                return {"success": False, "error": "Processing log not found"}
            log["id"] = log["_id"]
            del log["_id"]
            return {"success": True, "processing_log": log}
        except Exception as e:
            return {"success": False, "error": str(e)}