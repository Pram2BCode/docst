from uuid import uuid4
from datetime import datetime
from app.core.database import get_db

class DocumentService:
    def __init__(self):
        self.db = get_db()
        self.collection = self.db.documents

    def create_document(self, document_data: dict):
        try:
            document = {
                "_id": str(uuid4()),
                "project_id": document_data["project_id"],
                "document_name": document_data["document_name"],
                "original_filename": document_data["original_filename"],
                "file_path": document_data["file_path"],
                "file_size": document_data["file_size"],
                "file_type": document_data["file_type"],
                "mime_type": document_data["mime_type"],
                "total_pages": document_data["total_pages"],
                "access_mod_doc": document_data.get("access_mod_doc", "private"),
                "checksum": document_data["checksum"],
                "version": document_data.get("version", 1),
                "extraction_status": "pending",
                "extraction_metadata": {},
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            result = self.collection.insert_one(document)
            document["id"] = document["_id"]
            del document["_id"]
            return {"success": True, "document": document}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_document_by_id(self, document_id: str):
        try:
            document = self.collection.find_one({"_id": document_id})
            if not document:
                return {"success": False, "error": "Document not found"}
            document["id"] = document["_id"]
            del document["_id"]
            return {"success": True, "document": document}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_document(self, doc_id: str):
        try:
            self.db.pages.delete_many({"doc_id": doc_id})
            self.db.sections.delete_many({"doc_id": doc_id})
            self.db.tables.delete_many({"doc_id": doc_id})
            self.db.images.delete_many({"doc_id": doc_id})
            self.db.document_processing_log.delete_many({"doc_id": doc_id})
            result = self.collection.delete_one({"_id": doc_id})
            return {"success": True, "deleted_count": result.deleted_count}
        except Exception as e:
            return {"success": False, "error": str(e)}