from fastapi import FastAPI
from app.api.v1.routes import users, projects, documents, pages, sections, tables, images, processing_log
from app.services.schema_service import create_all_indexes
from app.core.database import get_db

app = FastAPI(title="Document Suite API")

# Initialize database indexes on startup
@app.on_event("startup")
async def startup_event():
    db = get_db()
    create_all_indexes(db)

# Include routers
app.include_router(users.router, prefix="/api/v1/users", tags=["users"])
app.include_router(projects.router, prefix="/api/v1/projects", tags=["projects"])
app.include_router(documents.router, prefix="/api/v1/documents", tags=["documents"])
app.include_router(pages.router, prefix="/api/v1/pages", tags=["pages"])
app.include_router(sections.router, prefix="/api/v1/sections", tags=["sections"])
app.include_router(tables.router, prefix="/api/v1/tables", tags=["tables"])
app.include_router(images.router, prefix="/api/v1/images", tags=["images"])
app.include_router(processing_log.router, prefix="/api/v1/documents/processing_log", tags=["processing_log"])