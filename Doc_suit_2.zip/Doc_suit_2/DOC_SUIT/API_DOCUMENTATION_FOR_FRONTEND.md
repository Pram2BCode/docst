# API Documentation for Frontend Developers

## 📄 Documents

Manage uploaded documents.

---

### 📤 POST `/api/v1/documents/`

**Description**: Upload up to 5 documents to a project.

- **Request Type**: `multipart/form-data`
- **Headers**:
  - `X-API-Key`: your secure API key
- **Body Parameters**:
  - `project_id` (string, required): UUID of the project
  - `files` (list, required): List of files (max 5)
  - `access_mod_doc` (string, optional): Access mode (`public` or `private`, default: `private`)

#### 🔍 Example Request:
```http
POST /api/v1/documents/ HTTP/1.1
Host: localhost:8000
X-API-Key: your_secure_api_key_here
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary

----WebKitFormBoundary
Content-Disposition: form-data; name="project_id"

6ba7b810-9dad-11d1-80b4-00c04fd430c8
----WebKitFormBoundary
Content-Disposition: form-data; name="access_mod_doc"

private
----WebKitFormBoundary
Content-Disposition: form-data; name="files"; filename="file1.pdf"
Content-Type: application/pdf

(binary data)
----WebKitFormBoundary
Content-Disposition: form-data; name="files"; filename="file2.pdf"
Content-Type: application/pdf

(binary data)
----WebKitFormBoundary
````

#### ✅ Response (201 Created):

```json
[
  {
    "id": "6ba7b811-9dad-11d1-80b4-00c04fd430c8",
    "project_id": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
    "document_name": "file1.pdf",
    "original_filename": "file1.pdf",
    "file_path": "/uploads/documents/file1.pdf",
    "file_size": 2048576,
    "file_type": "pdf",
    "mime_type": "application/pdf",
    "total_pages": 1,
    "access_mod_doc": "private",
    "extraction_status": "pending",
    "extraction_metadata": {},
    "created_at": "2025-06-11T10:30:00Z",
    "updated_at": "2025-06-11T10:30:00Z",
    "checksum": "placeholder_checksum",
    "version": 1
  },
  {
    "id": "6ba7b812-9dad-11d1-80b4-00c04fd430c8",
    "project_id": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
    "document_name": "file2.pdf",
    "original_filename": "file2.pdf",
    "file_path": "/uploads/documents/file2.pdf",
    "file_size": 1048576,
    "file_type": "pdf",
    "mime_type": "application/pdf",
    "total_pages": 1,
    "access_mod_doc": "private",
    "extraction_status": "pending",
    "extraction_metadata": {},
    "created_at": "2025-06-11T10:30:00Z",
    "updated_at": "2025-06-11T10:30:00Z",
    "checksum": "placeholder_checksum",
    "version": 1
  }
]
```

#### ❌ Errors:

* `400 Bad Request`: More than 5 files uploaded, invalid UUID, or invalid file type.
* `401 Unauthorized`: Invalid or missing API key.
* `500 Internal Server Error`: File write or server error.

---

### 📥 GET `/api/v1/documents/{document_id}`

**Description**: Retrieve a document by ID.

#### ✅ Response (200 OK):

Same structure as a single item in the POST response.

---

### 🗑️ DELETE `/api/v1/documents/{document_id}`

**Description**: Delete a document and its associated data.

#### ✅ Response (200 OK):

```json
{
  "message": "Deleted 1 document(s)"
}
```

```
